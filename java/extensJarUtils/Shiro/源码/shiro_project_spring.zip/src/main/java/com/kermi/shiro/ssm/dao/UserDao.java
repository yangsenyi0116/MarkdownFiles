package com.kermi.shiro.ssm.dao;

import com.kermi.shiro.ssm.pojo.User;

import java.util.List;

/**
 * @Author : Kermi
 * @Date : 2019/7/21 11:28 上午
 * @Version : 1.0
 */
public interface UserDao {
    User getUserByUserName(String userName);

    List<String> queryRolesByUserName(String userName);
}
