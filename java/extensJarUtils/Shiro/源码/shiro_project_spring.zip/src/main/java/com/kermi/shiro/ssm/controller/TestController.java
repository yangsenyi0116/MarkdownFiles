package com.kermi.shiro.ssm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @Author : Kermi
 * @Date : 2019/7/20 10:08 下午
 * @Version : 1.0
 */
@Controller
@RequestMapping("/test")
public class TestController {
    @RequestMapping("/t1")
    @ResponseBody
    public String test(){
        return "test";
    }
}
