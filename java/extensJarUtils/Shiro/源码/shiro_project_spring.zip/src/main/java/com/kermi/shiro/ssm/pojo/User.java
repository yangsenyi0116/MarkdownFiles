package com.kermi.shiro.ssm.pojo;

import lombok.Data;
import lombok.ToString;

/**
 * @Author : Kermi
 * @Date : 2019/7/20 09:38 下午
 * @Version : 1.0
 */
@Data
@ToString
public class User {
    private String username;
    private String password;
    private boolean rememberMe;

}
